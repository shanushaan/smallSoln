import requests


def getDataFromUser():
    retDir = {}
    name =raw_input("give me some name")
    data = raw_input("give me some name's data")
    return name,data


def postData():
    name,data=getDataFromUser()
    url = "http://localhost:5000/store/"+name
    res= requests.post(url, data=data)
    
postData()
