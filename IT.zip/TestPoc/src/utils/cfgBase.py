
def configReader():
    myvars= {}
    with open("../Constant.properties") as myfile:
        for line in myfile:
            spStr = line.split("=")
            myvars[spStr[0].strip()] = spStr[1].strip()
        
    
    return myvars
     
