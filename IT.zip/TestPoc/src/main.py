import openpyxl
import requests
import pytest
from utils.cfgBase import configReader
from requests.packages.urllib3 import response
import json

cfgs= configReader()

def readTestCasesXSL(sheetName, testCaseName):
    file = "..\\test-data\\ExcelTestData.xlsx"
    xlBook=openpyxl.load_workbook(file)
    sheet = xlBook[sheetName]
    testCaseData = []
    
    for row in sheet:
        if row[1].value == testCaseName:
            for cell in row[2:]:
                testCaseData.append(cell.value)
    
    testCaseTuple = tuple(testCaseData)
    return testCaseTuple


def getAuthToken(tcData):
    pwd = cfgs["strPassword"]
    usr = cfgs["strUserName"]
    strReqBody={"username":usr,"password":pwd}
    headers={"content-type":"application/json"}
    res = requests.post(cfgs["BASE_URL"]+"/auth", strReqBody,headers=headers)
    print res.status_code
    jsonDir = json.dumps(res.get_json())


def getHTML(url):
    return requests.get(url)
    




