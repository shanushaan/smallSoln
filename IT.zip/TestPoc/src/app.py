from flask import Flask, request
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World!"

@app.route("/<name>")
def returnName(name):
    return "Thankyou for trying :: "+name

@app.route("/store/<name>", methods=["POST", "DELETE"])
def storeVal(name):
    if request.method=="POST:"
        data = request.get_data()
        try:
            with open("reader.txt", "a+") as f:
                f.write(name+ " #$#::#$# " +data +"\n")
                return "data inserted"
            
        except Exception as ex:
            print ex
##    else:
##        with open("reader.txt") as f:
##            match = False
##            for line in f:
##                if line.startswith(name):
##                    match = True
##                    return line.split(" #$#::#$# ")[1].replace("\n","")
##    
##            if not match:
##                return "Data for " +name + " not found"
##    

@app.route("/getStored/<name>", methods=["GET"])
def getVal(name):
    with open("reader.txt") as f:
        match = False
        for line in f:
            if line.startswith(name):
                match = True
                return line.split(" #$#::#$# ")[1].replace("\n","")
    
        if not match:
            return "Data for " +name + " not found"

if __name__=="__main__":
    app.run()
