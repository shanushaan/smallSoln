import requests
import main
def test_data():
    res = main.getHTML("http://localhost:5000/getStored/Rohit")
    assert res.content == "789"   
    assert res.status_code ==200
